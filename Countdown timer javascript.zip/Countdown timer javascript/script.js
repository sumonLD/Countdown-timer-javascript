const daysTest = document.getElementById("days");
const hoursTest = document.getElementById("hours");
const minsTest = document.getElementById("mins");
const secondsTest = document.getElementById("seconds");



const newYr = '1 jan 2022';

function countdown() {

    const newYrdate = new Date(newYr);
    const currentDate = new Date();


    const totalseconds = Math.floor((newYrdate - currentDate) / 1000);
    const days = Math.floor(totalseconds / 3600 / 24);
    const hours = Math.floor(totalseconds / 3600) % 24;
    const minutes = Math.floor(totalseconds / 60) % 60;
    const seconds = Math.floor(totalseconds) % 60;

    daysTest.innerHTML = days;
    hoursTest.innerHTML = hours;
    minsTest.innerHTML = minutes;
    secondsTest.innerHTML = seconds;
}

function formateTime(time) {
    return time < 10 ? ('0${time}') : time;
}

countdown();

setInterval(countdown, 1000);